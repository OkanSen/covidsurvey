package com.example.covidsurvey;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefConfig {

    private static final String SURVEY_PREFS = "com.svavers.covidsurvey";
    private static final String PREF_NAME = "pref_name";
    private static final String PREF_SURNAME = "pref_surname";
    private static final String PREF_BIRTH_DATE = "pref_birth_date";
    private static final String PREF_CITY = "pref_city";
    private static final String PREF_GENDER = "pref_gender";
    private static final String PREF_V_TYPE = "pref_v_type";
    private static final String PREF_SIDE_EFF = "pref_side_eff";
    private static final String PREF_SUBMITTED = "pref_submitted";

    public static void saveSurveyDataInPref(Context context, String name, String surname, String birth_date, String city, String gender, String vaccine_type, String side_eff, int submitted){
        SharedPreferences pref = context.getSharedPreferences(SURVEY_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(PREF_NAME, name);
        editor.putString(PREF_SURNAME, surname);
        editor.putString(PREF_BIRTH_DATE, birth_date);
        editor.putString(PREF_CITY, city);
        editor.putString(PREF_GENDER, gender);
        editor.putString(PREF_V_TYPE, vaccine_type);
        editor.putString(PREF_SIDE_EFF, side_eff);
        editor.putInt(PREF_SUBMITTED, submitted);
        //editor.putString(PREF_IMAGE, image);
        editor.apply();
    }

    public static String loadNameFromPref(Context context){
        SharedPreferences pref = context.getSharedPreferences(SURVEY_PREFS, Context.MODE_PRIVATE);
        return pref.getString(PREF_NAME,"");
    }
    public static String loadSurnameFromPref(Context context){
        SharedPreferences pref = context.getSharedPreferences(SURVEY_PREFS, Context.MODE_PRIVATE);
        return pref.getString(PREF_SURNAME,"");
    }
    public static String loadBirthDateFromPref(Context context){
        SharedPreferences pref = context.getSharedPreferences(SURVEY_PREFS, Context.MODE_PRIVATE);
        return pref.getString(PREF_BIRTH_DATE,"");
    }
    public static String loadCityFromPref(Context context){
        SharedPreferences pref = context.getSharedPreferences(SURVEY_PREFS, Context.MODE_PRIVATE);
        return pref.getString(PREF_CITY,"");
    }
    public static String loadGenderFromPref(Context context){
        SharedPreferences pref = context.getSharedPreferences(SURVEY_PREFS, Context.MODE_PRIVATE);
        return pref.getString(PREF_GENDER,"");
    }
    public static String loadVTypeFromPref(Context context){
        SharedPreferences pref = context.getSharedPreferences(SURVEY_PREFS, Context.MODE_PRIVATE);
        return pref.getString(PREF_V_TYPE,"");
    }
    public static String loadSideEffFromPref(Context context){
        SharedPreferences pref = context.getSharedPreferences(SURVEY_PREFS, Context.MODE_PRIVATE);
        return pref.getString(PREF_SIDE_EFF,"");
    }
    public static int loadSubmittedFromPref(Context context){
        SharedPreferences pref = context.getSharedPreferences(SURVEY_PREFS, Context.MODE_PRIVATE);
        return pref.getInt(PREF_SUBMITTED,0);
    }


}
