package com.example.covidsurvey;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;

import com.bumptech.glide.Glide;
import com.google.android.material.appbar.CollapsingToolbarLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.example.covidsurvey.databinding.ActivityScrollingBinding;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ScrollingActivity extends AppCompatActivity {

    public static final String EXTRA_IMAGE = "com.example.covidsurvey.EXTRA_IMAGE";

    private ActivityScrollingBinding binding;

    private static final String TAG = "ScrollingActivity";

    private boolean name_filled;
    private boolean surname_filled;
    private boolean city_filled;

    private Button dateButton;
    private DatePickerDialog datePickerDialog;
    private static int RESULT_LOAD_IMAGE = 1;

    private static Uri path_to_img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityScrollingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);
        CollapsingToolbarLayout toolBarLayout = binding.toolbarLayout;
        toolBarLayout.setTitle(getTitle());

        // If somehow the user ends up in this page after submitting force them to the success page.
        int load_submitted = PrefConfig.loadSubmittedFromPref(getApplicationContext());
        if (load_submitted == 1){
            openSuccessActivity();
        }


        name_filled = false;
        surname_filled = false;
        city_filled = false;

        initDatePicker();
        dateButton = findViewById(R.id.date);
        dateButton.setText(getTodaysDate());

        // Set fields and buttons and etc...
        Button btn = (Button) findViewById(R.id.button);
        EditText name_field   = (EditText) findViewById(R.id.editTextTextPersonName);
        EditText surname_field   = (EditText) findViewById(R.id.editTextTextPersonName2);
        EditText city_field   = (EditText) findViewById(R.id.editTextTextPersonName3);
        Switch gender_switch = (Switch) findViewById(R.id.switch1);
        TextView female = (TextView) findViewById(R.id.textView7);
        TextView male = (TextView) findViewById(R.id.textView8);
        Spinner vaccineType = (Spinner) findViewById(R.id.spinner);
        Spinner sideEffs = (Spinner) findViewById(R.id.spinner2);

        // Image View
        ImageView imageView = (ImageView) findViewById(R.id.imgView);

        // Turn error message text invisible until it is summoned
        TextView error_text = (TextView) findViewById(R.id.error1);
        error_text.setVisibility(TextView.INVISIBLE);

        // Error messages from strings.xml
        String errormsg1 = getString(R.string.error1);
        String errormsg2 = getString(R.string.error2);
        String errormsg3 = getString(R.string.error3);
        String errormsg4 = getString(R.string.error4);
        String errormsg5 = getString(R.string.error5);

        // MAKE BUTTON UNCLICKABLE DURING OnCreate
        btn.setBackgroundColor(Color.GRAY);
        btn.setClickable(false);

        // Set color of gender at start
        if (gender_switch.isChecked()) {
            female.setTextColor(Color.BLACK);
            male.setTextColor(Color.RED);
        }
        else {
            male.setTextColor(Color.BLACK);
            female.setTextColor(Color.RED);
        }


        // Dynamic color change of male/female switch selection
        gender_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (gender_switch.isChecked()) {
                    female.setTextColor(Color.BLACK);
                    male.setTextColor(Color.RED);
                }
                else {
                    male.setTextColor(Color.BLACK);
                    female.setTextColor(Color.RED);
                }
            }
        });


        // BUTTON IS UNCLICKABLE WHEN FIELDS ARE EMPTY


        // NAME FIELD
        name_field.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!(name_field.getText().toString().length() == 0)){
                    name_filled = true;
                    if (name_filled && surname_filled && city_filled){
                        btn.setBackgroundColor(Color.GREEN);
                        btn.setClickable(true);
                    }
                }
                else{
                    name_filled = false;
                    btn.setBackgroundColor(Color.GRAY);
                    btn.setClickable(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        // SURNAME FIELD
        surname_field.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!(surname_field.getText().toString().length() == 0)){
                    surname_filled = true;
                    if (name_filled && surname_filled && city_filled){
                        btn.setBackgroundColor(Color.GREEN);
                        btn.setClickable(true);
                    }
                }
                else{
                    surname_filled = false;
                    btn.setBackgroundColor(Color.GRAY);
                    btn.setClickable(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        // CITY FIELD
        city_field.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!(city_field.getText().toString().length() == 0)){
                    city_filled = true;
                    if (name_filled && surname_filled && city_filled){
                        btn.setBackgroundColor(Color.GREEN);
                        btn.setClickable(true);
                    }
                }
                else{
                    city_filled = false;
                    btn.setBackgroundColor(Color.GRAY);
                    btn.setClickable(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });







        // WHEN SUBMIT IS PRESSED
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Seconds to wait in milliseconds
                Integer delay = 3000;

                // Pass filter boolean
                boolean validated = true;

                String name = name_field.getText().toString();
                String surname = surname_field.getText().toString();
                String city = city_field.getText().toString();

                Pattern symbols = Pattern.compile("[^a-z]", Pattern.CASE_INSENSITIVE);

                Matcher name_matcher = symbols.matcher(name);
                boolean name_matcher_bool = name_matcher.find();

                Matcher surname_matcher = symbols.matcher(surname);
                boolean surname_matcher_bool = surname_matcher.find();

                Matcher city_matcher = symbols.matcher(city);
                boolean city_matcher_bool = city_matcher.find();

                String gender;
                if (gender_switch.isChecked()) gender = "male";
                else gender = "female";

                // GET VACCINE TYPE AND SIDE EFFECT FROM SPINNERS
                String vaccine = vaccineType.getSelectedItem().toString();
                String side_effect = sideEffs.getSelectedItem().toString();
                String birth_date = (String) dateButton.getText();

                // NAME IS EMPTY
                if (name.length() == 0){
                    error_text.setText(errormsg1);
                    error_text.setVisibility(TextView.VISIBLE);

                    // Fire invisible maker after delay seconds
                    (new Handler()).postDelayed(this::CoroutineWaitForSeconds, delay);
                    validated = false;
                }
                // IF SURNAME IS EMPTY
                else if (surname.length() == 0){
                    error_text.setText(errormsg2);
                    error_text.setVisibility(TextView.VISIBLE);

                    // Fire invisible maker after delay seconds
                    (new Handler()).postDelayed(this::CoroutineWaitForSeconds, delay);
                    validated = false;
                }
                // IF CITY IS EMPTY
                else if (city.length() == 0){
                    error_text.setText(errormsg4);
                    error_text.setVisibility(TextView.VISIBLE);

                    // Fire invisible maker after delay seconds
                    (new Handler()).postDelayed(this::CoroutineWaitForSeconds, delay);
                    validated = false;
                }
                // NAME/SURNAME/CITY CONTAINS NUMERICS or UNWANTED CHARACTERS
                else if (name_matcher_bool || surname_matcher_bool || city_matcher_bool){
                    error_text.setText(errormsg3);
                    error_text.setVisibility(TextView.VISIBLE);

                    // Fire invisible maker after delay seconds
                    (new Handler()).postDelayed(this::CoroutineWaitForSeconds, delay);
                    validated = false;
                }
                // IF IMAGE IS EMPTY
                else if (imageView. getDrawable() == null){
                    error_text.setText(errormsg5);
                    error_text.setVisibility(TextView.VISIBLE);

                    // Fire invisible maker after delay seconds
                    (new Handler()).postDelayed(this::CoroutineWaitForSeconds, delay);
                    validated = false;
                }

                // If no test has failed then the credentials are validated
                if (validated){



                    String temp_name = PrefConfig.loadNameFromPref(getApplicationContext());
                    String temp_surname = PrefConfig.loadSurnameFromPref(getApplicationContext());
                    String temp_birth_date = PrefConfig.loadBirthDateFromPref(getApplicationContext());
                    String temp_city = PrefConfig.loadCityFromPref(getApplicationContext());
                    String temp_gender = PrefConfig.loadGenderFromPref(getApplicationContext());
                    String temp_v_type = PrefConfig.loadVTypeFromPref(getApplicationContext());
                    String temp_side_eff = PrefConfig.loadSideEffFromPref(getApplicationContext());




                    String appended_name = temp_name + "," + name;
                    String appended_surname = temp_surname + "," + surname;
                    String appended_birth_date = temp_birth_date + "," + birth_date;
                    String appended_city = temp_city + "," + city;
                    String appended_gender = temp_gender + "," + gender;
                    String appended_v_type = temp_v_type + "," + vaccine;
                    String appended_side_eff = temp_side_eff + "," + side_effect;

                    int submitted = 1;

                    PrefConfig.saveSurveyDataInPref(getApplicationContext(), appended_name, appended_surname, appended_birth_date, appended_city, appended_gender, appended_v_type, appended_side_eff, submitted);
                    openSuccessActivity();
                }


            }
            //
            public void CoroutineWaitForSeconds(){
                error_text.setVisibility(TextView.INVISIBLE);
            }
        });

        //for uploading picture
        Button buttonLoadImage = (Button) findViewById(R.id.buttonLoadPicture);
        buttonLoadImage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                Intent i = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

                startActivityForResult(i, RESULT_LOAD_IMAGE);
            }
        });


    }

    private String getTodaysDate() {
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        month = month + 1;
        int day = cal.get(Calendar.DAY_OF_MONTH);
        return makeDateString(day, month, year);
    }

    private void initDatePicker() {
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                month = month + 1;
                String date = makeDateString(dayOfMonth, month, year);
                dateButton.setText(date);
            }
        };
        Calendar cal = Calendar.getInstance();
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);

        int style = AlertDialog.THEME_HOLO_LIGHT;

        datePickerDialog = new DatePickerDialog(this, style, dateSetListener, year, month, day);
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
    }

    private String makeDateString(int dayOfMonth, int month, int year) {
        return getMonthFormat(month) + " " + dayOfMonth + " " + year;
    }

    private String getMonthFormat(int month) {
        if (month == 1)
            return "JAN";
        if (month == 2)
            return "FEB";
        if (month == 3)
            return "MAR";
        if (month == 4)
            return "APR";
        if (month == 5)
            return "MAY";
        if (month == 6)
            return "JUN";
        if (month == 7)
            return "JUL";
        if (month == 8)
            return "AUG";
        if (month == 9)
            return "SEP";
        if (month == 10)
            return "OCT";
        if (month == 11)
            return "NOV";
        if (month == 12)
            return "DEC";

        // default should never happen
        return "JAN";

    }

    public void openDatePicker(View view) {
        datePickerDialog.show();
    }


    public void openSuccessActivity(){
        Intent intent = new Intent(this, SuccessActivity.class);
        intent.putExtra(EXTRA_IMAGE,path_to_img);
        Log.d("asd","path to img" + path_to_img);
        startActivity(intent);
        finish();
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            SharedPreferences prefs = this.getSharedPreferences("com.svavers.covidsurvey", Context.MODE_PRIVATE);
            prefs.edit().putString("picString", selectedImage.toString()).apply();
            path_to_img = selectedImage;
            ImageView imageView = (ImageView) findViewById(R.id.imgView);
            Glide.with(this).load(selectedImage).into(imageView);
        }


    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_scrolling, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        //openScrollingActivity();
        finish();
    }






}