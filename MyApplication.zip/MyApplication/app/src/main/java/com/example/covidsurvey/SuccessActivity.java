package com.example.covidsurvey;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.nio.ByteBuffer;



public class SuccessActivity extends AppCompatActivity {
    private static int sum = 0;
    private Uri path;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        sum = sum + 1;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_success);

        // Normally this process wouldn't be needed since the intention is to give one submission per user
        // However, when testing we have the option to reset the variable of submission, hence we get multiple
        // entries. That is why we have to get the last entry from the database.
        String temp_name = PrefConfig.loadNameFromPref(getApplicationContext());
        String[] split_names = temp_name.split(",");
        temp_name = split_names[split_names.length - 1] + "!";

        SharedPreferences prefs = this.getSharedPreferences("com.svavers.covidsurvey", Context.MODE_PRIVATE);






        // Image View
        ImageView imageView = (ImageView) findViewById(R.id.imgView2);
        Log.d("a:","accessing path from prev activity");
        Log.d("c:","value of sum is =" + sum);

        Log.d("b:","create image form path" + path);

        path = Uri.parse(prefs.getString("picString", ""));
        Glide.with(this).load(path).into(imageView);





        TextView name_header = (TextView) findViewById(R.id.textView10);
        name_header.setText(temp_name);

        Button resetbtn = (Button) findViewById(R.id.resetbtn);
        Button clearbtn = (Button) findViewById(R.id.cleardb);

        resetbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int load_submitted = PrefConfig.loadSubmittedFromPref(getApplicationContext());

                if (load_submitted == 1){
                    load_submitted = 0;

                    String temp_name = PrefConfig.loadNameFromPref(getApplicationContext());
                    String temp_surname = PrefConfig.loadSurnameFromPref(getApplicationContext());
                    String temp_birth_date = PrefConfig.loadBirthDateFromPref(getApplicationContext());
                    String temp_city = PrefConfig.loadCityFromPref(getApplicationContext());
                    String temp_gender = PrefConfig.loadGenderFromPref(getApplicationContext());
                    String temp_v_type = PrefConfig.loadVTypeFromPref(getApplicationContext());
                    String temp_side_eff = PrefConfig.loadSideEffFromPref(getApplicationContext());


                    PrefConfig.saveSurveyDataInPref(getApplicationContext(), temp_name, temp_surname, temp_birth_date, temp_city, temp_gender, temp_v_type, temp_side_eff, load_submitted);
                    openScrollingActivity();
                }


            }
        });

        clearbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PrefConfig.saveSurveyDataInPref(getApplicationContext(), "", "", "", "", "", "", "", 1);
                Toast.makeText(getApplicationContext(),"Database cleared, press reset button to submit a new survey.", Toast.LENGTH_LONG).show();
            }
        });


    }
    @Override
    public void onBackPressed() {
        //openScrollingActivity();
        finish();
    }

    private void openScrollingActivity() {
        Intent intent = new Intent(this, ScrollingActivity.class);
        startActivity(intent);
        finish();
    }


}